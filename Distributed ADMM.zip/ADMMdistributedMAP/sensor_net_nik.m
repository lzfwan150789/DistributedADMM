% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
clear;
noOfNodes  = 20; %Total Number of nodes  
sen_Nodes = 20;  % Number of Sensor Nodes 
comNodes = 0; % Number of communication nodes  
figure(1);
clf;
grid on
% xticks(-300:600:6000);
% yticks(-3000:600:2400);
hold on;
R = 2000; % maximum range in meters;
sen1_Xloc = xlsread('Sensor_Net.xlsx',1,'D3:D8'); % list of TOA Sensor X coord.
sen1_Yloc = xlsread('Sensor_Net.xlsx',1,'E3:E8'); % List of TOA sensor Nodes Y coordinate.
comXloc = xlsread('Sensor_Net.xlsx',1,'A3:A16'); % List of Comm Nodes X coord.
comYloc = xlsread('Sensor_Net.xlsx',1,'B3:B16'); % List of Comm Nodes Y coord.
netXloc = [sen1_Xloc;comXloc];  % Augment all lists 
netYloc = [sen1_Yloc;comYloc];
for i = 1:noOfNodes
    figure(1)
    p1 = plot(netXloc(i), netYloc(i), 'ko', 'MarkerFaceColor','red');
    %text(netXloc(i), netYloc(i), num2str(i));
end
hold on

for i = 1:noOfNodes
    for j = 1:noOfNodes
            distance = sqrt((netXloc(i) - netXloc(j))^2 + (netYloc(i) - netYloc(j))^2);
            if distance <= R
                matrix(i, j) = 1;   % there is a link;
              p3 =   line([netXloc(i) netXloc(j)], [netYloc(i) netYloc(j)],'Color','blue', 'Linestyle','-');
            else
                matrix(i, j) = inf;
            end
    end
end
legend([p1,p3],{'Nodes', 'Link'});   

w = matrix; 
for i = 1:numel(w)
    if w(i) == Inf
        w(i) = 0;
    end
end
for i = 1:noOfNodes
    w(i,i) = 0;
    for j = 1:noOfNodes
            if ((i ~= j) && (w(i,j) ~= 0))
                X = matrix(i,:);
                Y = matrix(j,:); 
                w(i,j) = 1/(1+(max(numel(X(X~=Inf)), numel(Y(Y~= Inf)))));
            end
    end
end

for i = 1:noOfNodes
    w(i,i) = 1 - (sum(w(i,:)));
end

% Metropolis wieght matrix has been constructed and working fine.

