% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
% INPUT sen_Nodes : NO of sensor nodes
%       lambda    : Mean of possion distribution
%       gt        : ground truth paras
%       Cv        : meas noise covariance
% output  Y       : �mmeas
function [Y,nk]=generate_meas(noOfNodes,gt,Cv)
	Y = cell(1,noOfNodes);    
	for i = 1:noOfNodes
		Y{i}= gt(1:2) + mvnrnd([0 0], Cv, 1)';
	end
end