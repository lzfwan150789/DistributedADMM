% generate toplogy
Nc = 20; % total 20 nodes, where 6 sensor_node
[E,posSensor,SenNode] = getConnectivitySparse(Nc);
posSenNode = posSensor(:,SenNode); % position of sensor_node
posComNode = posSensor;
posComNode(:,SenNode) = [];  % position of comm_node

figure
hold on;
for i = 1:Nc-1
    for j = i+1:Nc
        if E(i,j)
            plot(posSensor(1,[i,j]),posSensor(2,[i,j]),'b-');
        end
    end
end

plot(posSenNode(1,:),posSenNode(2,:),'^','MarkerFaceColor',[1,0,0],'MarkerEdgeColor',[0,0,0]);
plot(posComNode(1,:),posComNode(2,:),'sk');
axis([-200,6000,-4000,4000]);