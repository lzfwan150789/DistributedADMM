% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com 
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
tic
clear;
clc;
close all;

%% To construct wieght matrix and the sensor network
run sensor_net_nik
 
%% Set parameters
% nearly constant velocity model 
H = [1 0 0 0; 0 1 0 0];
Ar =[1 0 1 0; 0 1 0 1; 0 0 1 0; 0 0 0 1] ;

Cv = diag([200 8]); % covariance of the measurement noise
Cwr = diag([50 50 10 10]); % covariance of the process noise for the kinematic state


M = 1; % Monte Carlo Runs
L = 20 ; % ADMM iteration step
rho = 100 ; % penalty parameter
 
 

MATRIX_r = cell(noOfNodes,5,L,M);

for m=1:M
	 %% Generate ground truth
	[gt_center, gt_vel, time_steps, time_interval] = get_ground_truth;
	gt = [gt_center;gt_vel];
	for L_=1:L
		% 1st Column of MATRIX_r&p is state vector
		for i = 1:noOfNodes
			MATRIX_r{i,1,L_,m}(:,1)=  [20, 20,90, -80]';
		end	

		% 3rd Column of MATRIX is corresponding information MATRIX
		% Initial Information matrix is set to inv(P)
		for i = 1:noOfNodes
			MATRIX_r{i,3,L_,m}(:,:,1) = (diag([900 900 16 16]))^(-1);
		end
		% 2nd Column of MATRIX is corresponding prior information MATRIX
		% Initial Information matrix is set to inv(P)*x(k|k-1)			
		for i = 1:noOfNodes
			MATRIX_r{i,2,L_,m} = MATRIX_r{i,3,L_,m}(:,:,1)*MATRIX_r{i,1,L_,m}(:,1);
		end
		% 4th Column of MATRIX is corresponding mea information MATRIX
		for i = 1:noOfNodes
			MATRIX_r{i,4,L_,m} =  [0;0;0;0];
		end
		% 5th Column of MATRIX is corresponding mea cov information MATRIX
		for i = 1:noOfNodes
			MATRIX_r{i,5,L_,m} = zeros(4);
		end		
		% Main WSN_EOT Algorithm
		for k = 2:time_steps
			%% Prediction update 
            for i = 1:noOfNodes
                MATRIX_r{i,1,L_,m}(:,k) = Ar*MATRIX_r{i,1,L_,m}(:,k-1);   % x(t|t-1)
            end
            for i = 1:noOfNodes
                MATRIX_r{i,3,L_,m}(:,:,k)= time_update(MATRIX_r{i,3,L_,m}(:,:,k-1),Ar,Cwr); % inv(P(t|t-1))
            end			
           %% Generate Measurement 
            Y = generate_meas(noOfNodes,gt(:,k),Cv);
                for i = 1:noOfNodes
                    MATRIX_r{i,2,L_,m}= MATRIX_r{i,3,L_,m}(:,:,k)*MATRIX_r{i,1,L_,m}(:,k); % inv(P(t|t-1))*x(t|t-1)
                end            
                %% Generate information MATRIX w.r.t measurement
                for i = 1:noOfNodes
% 					V_r = chol(MATRIX_r{i,3,L_,m}(:,:,k)); inv_sqrt_r = inv(V_r); inv_r = inv_sqrt_r*inv_sqrt_r';
% 					V_p = chol(MATRIX_p{i,3,L_,m}(:,:,k)); inv_sqrt_p = inv(V_p); inv_p = inv_sqrt_p*inv_sqrt_p';
					MATRIX_r{i,4,L_,m} = H'*Cv^(-1)*Y{i};
                    MATRIX_r{i,5,L_,m} = H'*Cv^(-1)*H;                    
                end
              %% ADMM operation	
                % Consensus on ADMM for state vector
				MATRIX_r1_temp = cell(noOfNodes,1);
				MATRIX_r3_temp = cell(noOfNodes,1);

				for ii=1:noOfNodes
					MATRIX_r1_temp{ii} = MATRIX_r{ii,1,L_,m}(:,k);
					MATRIX_r3_temp{ii} = MATRIX_r{ii,3,L_,m}(:,:,k);				
				end
				[MATRIX_r1] = ADMM(noOfNodes,L_,MATRIX_r1_temp,MATRIX_r(:,2,L_,m),MATRIX_r3_temp,MATRIX_r(:,4,L_,m),MATRIX_r(:,5,L_,m),matrix,rho);				
				
				% Consensus on Novel mea information vector for shape and kinematic state
                [MATRIX_r5]=consensus(noOfNodes,10,MATRIX_r(:,5,L_,m),matrix,eps);
                for i= 1:noOfNodes
                    MATRIX_r{i,5,L_,m} = MATRIX_r5{i};
                end	
                		
				%% Correction operation
                for i = 1:noOfNodes
                    MATRIX_r{i,3,L_,m}(:,:,k) = MATRIX_r{i,3,L_,m}(:,:,k) + noOfNodes.*MATRIX_r{i,5,L_,m};
                end
                for i = 1:noOfNodes
                    MATRIX_r{i,1,L_,m}(:,k) = MATRIX_r1{i};
                end
		end
	end
end

%% visualize estimate and ground truth for every 3rd scan
est_r=zeros(4,time_steps,M);
for i=1:M
    est_r(:,:,i) = cell2mat(MATRIX_r(1,1,L,i));
end
mean_MATRIX_r=mean(est_r,3);

axis equal
gt_plot = plot(gt(1, :),gt(2, :),'LineStyle','-','color','b','LineWidth',1.5);
est_plot = plot(mean_MATRIX_r(1,:),mean_MATRIX_r(2,:),'LineStyle','-.','color','r','LineWidth',1.5); 

legend([gt_plot, est_plot], {'Ground truth', 'Estimate'},'Location','northwest');
toc