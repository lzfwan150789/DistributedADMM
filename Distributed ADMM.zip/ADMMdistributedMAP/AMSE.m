% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
function filter_amse = AMSE(target_est,true_state)
% compute the average mean square error
cellsz =  cellfun(@size,target_est,'uni',false);
num_steps = cellsz{1}(2);
L = size(target_est,3);
Monte = size(target_est,4);
filter_amse = zeros(num_steps,L);

for L_ = 1:L
	for k = 1:num_steps
		error = zeros(1,1);
		for m = 1:Monte
			error = error + norm (true_state(:,k) - target_est{1,1,L_,m}(:,k));
		end
		filter_amse(k,L_) = error/Monte;
	end
end        
end