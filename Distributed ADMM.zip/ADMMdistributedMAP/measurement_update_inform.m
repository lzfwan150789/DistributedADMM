% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================

function [H_r_infor,y_r_infor,H_p_inform,Y_p_inform] = measurement_update_inform(y,H,r,p,Cr,Cp,Ch,Cv)
    nk = size(y,2); % number of measurements at time k
    [CI,CII,CIII,M,F,Ftilde] = get_auxiliary_variables(p,r,Cp,Cr(3:4,3:4),Ch);
    
    % calculate noise cov information(i.e., H'*R^(-1)*H) and mea vector information (i.e., H'*R^(-1)*y) for the kinematic state 
    H_r=repmat(H,nk,1);
    yibar = H_r*r; 
	
	blkdiagonal_r = repmat({(CI+CII+CIII+Cv)},nk,1);
	H_r_infor = H_r'*blkdiag(blkdiagonal_r{:})^(-1)*H_r;
	y_r_infor = H_r'*blkdiag(blkdiagonal_r{:})^(-1)*reshape(y,[],1);
	
    % temp variables for shape pseudo-mea
    Ybar = repmat(F*reshape((H*Cr*H'+CI+CII+CIII+Cv),[4,1]),nk,1);
    CY_temp = F*kron((H*Cr*H'+CI+CII+CIII+Cv),(H*Cr*H'+CI+CII+CIII+Cv))*(F + Ftilde)';
	
    Y=zeros(3*nk,1); % initialization
    % construct pseudo-measurement for the shape update
    for i=1:nk
         Y(3*i-2:3*i,:) = F*kron(y(:,i)-yibar(2*i-1:2*i,:),y(:,i)-yibar(2*i-1:2*i,:)); 
        % calculate moments for the shape update        
    end
    
    H_p=repmat(M,nk,1);    
	blkdiagonal_p=repmat({(CY_temp-M*Cp*M')},nk,1);
    % caiculate information variables for shape 
	H_p_inform = H_p'*blkdiag(blkdiagonal_p{:})^(-1)*H_p;
    Y_p_inform = H_p'*blkdiag(blkdiagonal_p{:})^(-1)*(Y-Ybar+H_p*p);
end


function [CI,CII,CIII,M,F,Ftilde] = get_auxiliary_variables(p,r,Cp,Cr,Ch)
l1 = p(1);
l2 = p(2);
vx = r(3) ;
vy = r(4) ;
S = [vx/norm(r(3:4)) -vy/norm(r(3:4)); vy/norm(r(3:4)) vx/norm(r(3:4))]*diag([l1 l2]);
S1 = S(1,:);
S2 = S(2,:);

dS1_dv = [ l1*(1/norm(r(3:4))-vx^2/norm(r(3:4))^3) -l1*vx*vy/norm(r(3:4))^3; l2*vx*vy/norm(r(3:4))^3 -l2*(1/norm(r(3:4))-vy^2/norm(r(3:4))^3)];
dS2_dv = [ -l1*vx*vy/norm(r(3:4))^3 l1*(1/norm(r(3:4))-vy^2/norm(r(3:4))^3); l2*(1/norm(r(3:4))-vx^2/norm(r(3:4))^3) -l2*vx*vy/norm(r(3:4))^3];

dS1_dl = [ vx/norm(r(3:4)) 0; 0 -vy/norm(r(3:4))];
dS2_dl = [ vy/norm(r(3:4)) 0; 0 vx/norm(r(3:4))];

CI = S*Ch*S';
CII(1,1) = trace(Cr*dS1_dv'*Ch*dS1_dv);
CII(1,2) = trace(Cr*dS2_dv'*Ch*dS1_dv);
CII(2,1) = trace(Cr*dS1_dv'*Ch*dS2_dv);
CII(2,2) = trace(Cr*dS2_dv'*Ch*dS2_dv);

CIII(1,1) = trace(Cp*dS1_dl'*Ch*dS1_dl);
CIII(1,2) = trace(Cp*dS2_dl'*Ch*dS1_dl);
CIII(2,1) = trace(Cp*dS1_dl'*Ch*dS2_dl);
CIII(2,2) = trace(Cp*dS2_dl'*Ch*dS2_dl);


M = [2*S1*Ch*dS1_dl; 2*S2*Ch*dS2_dl; S1*Ch*dS2_dl + S2*Ch*dS1_dl];

F = [1 0 0 0; 0 0 0 1; 0 1 0 0];
Ftilde = [1 0 0 0; 0 0 0 1; 0 0 1 0];
end