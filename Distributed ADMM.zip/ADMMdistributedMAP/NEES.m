% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
function filter_nees = NEES(target_est,target_cov,true_state)
% compute the normalized estimation error squared

cellsz =  cellfun(@size,target_est,'uni',false);
num_steps = cellsz{1}(2);
L = size(target_est,3);
Monte = size(target_est,4);

filter_nees = zeros(num_steps,L);
for L_ = 1:L
    for k = 1:num_steps
          for m = 1:Monte  
            est_error = true_state(:,k) - target_est{1,1,L_,m}(:,k);
            filter_nees(k,L_) = filter_nees(k,L_) + est_error'*target_cov{1,1,L_,m}(:,:,k)*est_error;
          end
    end
    filter_nees(:,L_) = filter_nees(:,L_)/Monte;
end        
end



