% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
function filter_acee = ACEE(target_est)
% compute the average consensus estimate error
cellsz =  cellfun(@size,target_est,'uni',false);
num_steps = cellsz{1,1,1}(2); % number of time steps
Ns = size(target_est,1); % number of sensors
L = size(target_est,3); % number of consensus iteration
Monte = size(target_est,4); % number of Monte

filter_acee = zeros(num_steps,L);
for L_ = 1:L
    for m = 1:Monte
        for k = 1:num_steps
            for i = 1:Ns-1
                for i_ = (i+1):Ns
                    filter_acee(k,L_) = filter_acee(k,L_) + norm(target_est{i_,1,L_,m}(:,k) - target_est{i,1,L_,m}(:,k));
                end
            end            
        end        
    end
    filter_acee(:,L_) = 2*filter_acee(:,L_)/(Ns*(Ns - 1))/Monte;
end
end

