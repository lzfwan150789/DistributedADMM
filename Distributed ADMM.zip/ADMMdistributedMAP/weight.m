% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
% INPUT noOfNodes : NO of nodes
%       L_        : No of consensus iteration
%       sen_Nodes : NO of sensor nodes
%       w         : Metropolis wieght matrix
% output  binary  : �Wweight coefficient
function [binary]=weight(noOfNodes,sen_Nodes,w,L_)
	binary=zeros(1,noOfNodes);
	for i = 1:sen_Nodes
		binary(i)=1;
	end
	CONS = zeros(1,noOfNodes);
	for l = 1:L_
            for i = 1:noOfNodes
                 temp = 0;
                 for j = 1:noOfNodes
                       temp = (w(i,j).* binary(j))+ temp;
                 end
             CONS(i) = temp;
            end
		for i= 1:noOfNodes
			binary(i) = CONS(i); 
		end
	end	
	for i = 1:noOfNodes
		if abs(binary(i)) < eps
			binary(i) = 1;
		else
			binary(i) = 1/binary(i);					
		end
	end
end