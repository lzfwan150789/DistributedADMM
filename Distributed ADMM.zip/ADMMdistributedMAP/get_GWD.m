% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
% INPUT   gt : True state
%         MATRIX_r : estimated kinematic
%         MATRIX_p : estimated shape 
% OUTPUT  GWD
function [GWD]=get_GWD(gt,MATRIX_r,MATRIX_p)
cellsz =  cellfun(@size,MATRIX_r,'uni',false);
num_steps = cellsz{1}(2);
L = size(MATRIX_r,3); % number of consensus 
Monte = size(MATRIX_r,4);
GWD=zeros(num_steps,L);
for L_=1:L	
    for k=1:num_steps
        for m=1:Monte
        GWD(k,L_) = GWD(k,L_)+ d_gaussian_wasserstein( gt(:,k), [MATRIX_r{1,1,L_,m}(1:2,k) ; MATRIX_p{1,1,L_,m}(:,k)]);
        end
    end
	GWD(:,L_) = GWD(:,L_)/Monte;
end