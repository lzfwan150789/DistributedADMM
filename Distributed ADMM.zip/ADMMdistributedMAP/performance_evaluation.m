%% performance comparison
% Gaussian wasserstein distance (GWD)
load matlab100.mat

% normalize estimation error squared(NEES);
confidence_interval_kine = chi2inv([0.025,0.975],4*M)/M; % 95% confidence level
confidence_interval_shape = chi2inv([0.025,0.975],3*M)/M;

ness_kine = NEES(MATRIX_r(10,1,:,:),MATRIX_r(10,3,:,:),gt);

% averaged consensus estimation error(ACEE);
acee_kine = ACEE(MATRIX_r(:,1,:,:));

% averaged mean squared error
amse_kine = AMSE(MATRIX_r(10,1,:,:),gt);




