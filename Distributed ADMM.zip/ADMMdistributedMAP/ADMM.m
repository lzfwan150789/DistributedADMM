% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
% 
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
% INPUT noOfNodes : NO of nodes
%       L_        : No of iteration
%		MATRIX1   : prior state is set to x(k|k-1)
%		MATRIX2   : prior information MATRIX is set to inv(P)*x(k|k-1)
%		MATRIX3   : information MATRIX is set to inv(P)
%       MATRIX4   : mea information MATRIX is set to H*R^(-1)*y
%		MATRIX5   : cov information MATRIX is set to H*R^(-1)*H^T
%       E         : adjacent matrix
%       rho       : penalty parameter
% OUTPUT MATRIX   : iterated MATRIX1
function [MATRIX1] = ADMM(noOfNodes,L_,MATRIX1,MATRIX2,MATRIX3,MATRIX4,MATRIX5,E,rho)
	cellsz = cellfun(@size,MATRIX1,'uni',false);
	lambd = zeros(cellsz{1}(1),1,noOfNodes,noOfNodes);
% 	ConsSta = cell(1,noOfNodes);
% 	ConsLamb = cell(1,noOfNodes);
	for l = 1:L_
		for i = 1:noOfNodes
			for j = 1:noOfNodes
				 if E(i,j)==1
				   lambd(:,:,i,j) = UpdateDualVariables(lambd(:,:,i,j),MATRIX1{i},MATRIX1{j},rho);
				 end
			end		 
		end
		OldMATRIX1 = MATRIX1;
		for i = 1:noOfNodes 
		 TempSta = MATRIX2{i}./noOfNodes + MATRIX4{i} ;
		 X = E(i,:);
		 Delta = numel(X(X~=Inf));
			 for j = 1:noOfNodes
				 if E(i,j)==1
				   TempSta = TempSta +lambd(:,:,i,j) +  OldMATRIX1{j}./rho;
				 end
			 end
		 MATRIX1{i} =(MATRIX5{i} + MATRIX3{i}./noOfNodes + eye(cellsz{1}(1))./rho*Delta)^(-1)*TempSta ;
		end
	end	

end