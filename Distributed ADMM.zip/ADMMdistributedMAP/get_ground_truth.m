% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed consensus-based filter for Extended Object"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================


function [gt_center, gt_vel, time_steps, time_interval] = get_ground_truth
%% -------------Setting ground truth---------------------------------------
gt_center(:, 1) = [0, 0]';
% trajectory
gt_orient = [ repmat(-pi/4, 1, 20), (-pi/4: pi/40:0), ...
   zeros(1, 10), (0: pi/20:2*pi/4), ....
    repmat(2*pi/4, 1, 20), (2*pi/4: pi/20:pi), ....
    repmat(pi, 1, 20)];
% assume object is aligned along its velocity
gt_vel = [(5000/36)*cos(gt_orient);(5000/36)*sin(gt_orient)];

time_steps = size(gt_vel, 2);
time_interval = 1;

for t = 1 : time_steps
	if t>1
		gt_center(:, t) = gt_center(:, t-1) + gt_vel(:, t)*time_interval ;
	end
end


end

