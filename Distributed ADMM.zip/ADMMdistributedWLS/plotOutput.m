%% show estimated results
L_ = 20; 

% %% show NEES
% figure;
% hold on;
% % show NEES with fixed no. of iterations
% 
% plot((1:time_steps),ness_kine(:,L_),'gs-.','LineWidth',1);
% 
% plot((1:time_steps),confidence_interval_kine(1)*ones(1,time_steps),'k--','LineWidth',1);
% plot((1:time_steps),confidence_interval_kine(2)*ones(1,time_steps),'k--','LineWidth',1);
% 
% xlabel('Time (s)');ylabel('NEES');
% legend('NESS_kine');
% 
% %% show NEES with different no. of consensus iterations 
% figure
% hold on;
% plot(1:L,mean(ness_kine),'gs-.','LineWidth',1);
% xlabel('Consensus Iterations'); ylabel('Average NESS');
% legend('NESS_kine');
 
%% show ACEE
% show ACEE with fixed no. of consensus iterations
figure
subplot(2,1,1)
ACEE_r = plot((1:time_steps),acee_kine(:,L_),'rx-.','LineWidth',1.5);
legend( ACEE_r, { 'DWLSE Estimate'},'Location','northeast');
xlabel('Time (s)'); ylabel('ACEE in state');
%% show ACEE with different no. of consensus iterations 
figure
subplot(2,1,2)
Ave_ACEE_r = plot(1:L,mean(acee_kine),'rx-.','LineWidth',1.5);
legend( Ave_ACEE_r, { 'DWLSE Estimate'},'Location','northeast');
xlabel('Consensus Iterations'); ylabel('Average ACEE');

%% show AMSE
% show AMSE with fixed no. of consensus iterations
figure
subplot(2,1,1)
AMSE_r = plot((1:time_steps),amse_kine(:,L_),'rx-.','LineWidth',1.5);
legend( AMSE_r, { 'DWLSE Estimate'},'Location','northeast');
xlabel('Time (s)'); ylabel('AMSE in state');
%% show ACEE with different no. of consensus iterations 
figure
subplot(2,1,2)
Ave_AMSE_r = plot(1:L,mean(amse_kine),'rx-.','LineWidth',1.5);
legend( Ave_AMSE_r, { 'DWLSE Estimate'},'Location','northeast');
xlabel('Consensus Iterations'); ylabel('Average AMSE');