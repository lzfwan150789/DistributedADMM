%% show estimated results

% %% show NEES
% figure;
% hold on;
% % show NEES with fixed no. of iterations
% 
% plot((1:time_steps),ness_kine(:,L_),'gs-.','LineWidth',1);
% 
% plot((1:time_steps),confidence_interval_kine(1)*ones(1,time_steps),'k--','LineWidth',1);
% plot((1:time_steps),confidence_interval_kine(2)*ones(1,time_steps),'k--','LineWidth',1);
% 
% xlabel('Time (s)');ylabel('NEES');
% legend('NESS_kine');
% 
% %% show NEES with different no. of consensus iterations 
% figure
% hold on;
% plot(1:L,mean(ness_kine),'gs-.','LineWidth',1);
% xlabel('Consensus Iterations'); ylabel('Average NESS');
% legend('NESS_kine');
%% show AMSE
% show AMSE with fixed no. of consensus iterations
figure
AMSE_r = plot((1:time_steps),amse_kine(:,1),'gs-.','LineWidth',1.5);
legend( AMSE_r, { 'Centralized Estimate'},'Location','northeast');
xlabel('Time (s)'); ylabel('AMSE in state');