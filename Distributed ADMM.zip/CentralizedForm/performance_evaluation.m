%% performance comparison
% Gaussian wasserstein distance (GWD)
load matlab.mat

% averaged mean squared error
amse_kine = AMSE(MATRIX_r(1,1,:),gt);




