% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com 
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
tic
clear;
clc;
close all;

%% To construct wieght matrix and the sensor network
run sensor_net_nik
 
%% Set parameters
% nearly constant velocity model 
H = [1 0 0 0; 0 1 0 0];
Ar =[1 0 1 0; 0 1 0 1; 0 0 1 0; 0 0 0 1] ;

Cv = diag([200 8]); % covariance of the measurement noise
Cwr = diag([50 50 10 10]); % covariance of the process noise for the kinematic state


M = 1; % Monte Carlo Runs
MATRIX_r = cell(1,5,M);

for m=1:M
	 %% Generate ground truth
	[gt_center, gt_vel, time_steps, time_interval] = get_ground_truth;
	gt = [gt_center;gt_vel];
    % 1st Column of MATRIX_r&p is state vector
    MATRIX_r{1,1,m}(:,1)=  [20, 20,90, -80]';
    % 3rd Column of MATRIX is corresponding information MATRIX
    % Initial Information matrix is set to inv(P)
    MATRIX_r{1,3,m}(:,:,1) = (diag([900 900 16 16]))^(-1);
    % 2nd Column of MATRIX is corresponding prior information MATRIX
    % Initial Information matrix is set to inv(P)*x(k|k-1)			
    MATRIX_r{1,2,m} = MATRIX_r{1,3,m}(:,:,1)*MATRIX_r{1,1,m}(:,1);
    % 4th Column of MATRIX is corresponding mea information MATRIX
    MATRIX_r{1,4,m} =  [0;0;0;0];
    % 5th Column of MATRIX is corresponding mea cov information MATRIX
    MATRIX_r{1,5,m} = zeros(4);	
		% Main WSN_EOT Algorithm
    for k = 2:time_steps
        %% Prediction update 
        MATRIX_r{1,1,m}(:,k) = Ar*MATRIX_r{1,1,m}(:,k-1);   % x(t|t-1)
        MATRIX_r{1,3,m}(:,:,k)= time_update(MATRIX_r{1,3,m}(:,:,k-1),Ar,Cwr); % inv(P(t|t-1))			
       %% Generate Measurement 
        Y = generate_meas(noOfNodes,gt(:,k),Cv);
        MATRIX_r{1,2,m}= MATRIX_r{1,3,m}(:,:,k)*MATRIX_r{1,1,m}(:,k); % inv(P(t|t-1))*x(t|t-1)          
       %% Generate information MATRIX w.r.t measurement
        MATRIX_r{1,4,m} = [0;0;0;0];
        for i =1:noOfNodes
            MATRIX_r{1,4,m} = H'*Cv^(-1)*Y{i}+MATRIX_r{1,4,m};
        end        
        MATRIX_r{1,5,m} = H'*Cv^(-1)*H;                    
        %% Correction operation
        MATRIX_r{1,3,m}(:,:,k) = MATRIX_r{1,3,m}(:,:,k) + noOfNodes.*MATRIX_r{1,5,m};
        MATRIX_r{1,1,m}(:,k) = MATRIX_r{1,3,m}(:,:,k)\(MATRIX_r{1,2,m} + MATRIX_r{1,4,m});
    end
end

%% visualize estimate and ground truth for every 3rd scan
est_r=zeros(4,time_steps,M);
for i=1:M
    est_r(:,:,i) = cell2mat(MATRIX_r(1,1,i));
end
mean_MATRIX_r=mean(est_r,3);

axis equal
gt_plot = plot(gt(1, :),gt(2, :),'LineStyle','-','color','b','LineWidth',1.5);
est_plot = plot(mean_MATRIX_r(1,:),mean_MATRIX_r(2,:),'LineStyle','-.','color','r','LineWidth',1.5); 

legend([gt_plot, est_plot], {'Ground truth', 'Estimate'},'Location','northwest');
toc