% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
% INPUT noOfNodes : NO of nodes
%       L_        : No of consensus iteration
%       MATRIX    : input vector
%       E         : adjacent matrix
%       eps       : consensus rate parameter
% output MATRIX   ��consensus MATRIX
function [MATRIX]=consensus(noOfNodes,L_,MATRIX,E,eps)
	CONS = cell(1,noOfNodes);
    if iscell(MATRIX)
        cellsz = cellfun(@size,MATRIX,'uni',false);
        for l = 1:L_
            for i = 1:noOfNodes 
             temp = zeros(cellsz{1}(1),cellsz{1}(2));
             X = E(i,:);
             Delta = numel(X(X~=Inf));
                 for j = 1:noOfNodes
                     if E(i,j)==1
                       temp = MATRIX{j}+ temp;
                     end
                 end
             CONS{i} = (1-Delta*eps)*MATRIX{i} + eps*temp;
            end
            for i= 1:noOfNodes
                MATRIX{i} = CONS{i};
            end
        end	
    else
        cellsz = size(MATRIX(:,:,1));
        for l = 1:L_
            for i = 1:noOfNodes 
             temp = zeros(cellsz(1),cellsz(2));
             X = E(i,:);
             Delta = numel(X(X~=Inf));
                 for j = 1:noOfNodes
                     if E(i,j)==1
                       temp = MATRIX(:,:,j)+ temp;
                     end
                 end
             CONS{i} = (1-Delta*eps)*MATRIX(:,:,i) + eps*temp;
            end
            for i= 1:noOfNodes
                MATRIX(:,:,i) = CONS{i};
            end
        end        
    end
end