
%% All of sensors (includes sensor nodes and communication nodes) are randomly distributed in a retangualr region [-200m, 6200m]��[-3000m, 2500m]
function [E,posSensor,SenNode] = getConnectivitySparse(Nc)
    
    % set communication link
    while 1
        E = zeros(Nc);
		pos_x=-200+6200*rand(1,Nc);
		pos_y=-3000 + 5500 * rand(1,Nc);
        posSensor = [pos_x;pos_y];

        for i = 1:Nc-1
            for j = i+1:Nc
                d = norm(posSensor(:,j) - posSensor(:,i));
                if  d < 2000
                    E(i,j) = 1;
                end 
            end
        end
        E = E + E';

        if any(sum(E) == 0) 
            continue;
        else
            break;
        end
    end
    SenNode = randperm(Nc,6);

end



