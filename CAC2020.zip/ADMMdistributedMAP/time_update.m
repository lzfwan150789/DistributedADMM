% Implementation of the WSN_EOT algorithm based on the article
% 
% "Disributed Consensus-based Filter for Extended Object Tracking"
% Zhifei Li and Jianyun Zhang
%
% Further information:
% email:lizhifei17@nudt.edu.cn/lizhifei0912@gmail.com
% 
% Source code written by Zhifei Li
% In Tianjin, March, 2020
% =============================
% INPUT MATRIX_r : inverse state cov
%       Ar    : state transition matrix
%       Cwr        : process noise covariance
% output  MATRIX_r       : �uupdated inverse state cov
function [MATRIX_r]= time_update(MATRIX_r,Ar, Cwr)           
% MATRIX_r = Cwr^(-1) - (Cwr^(-1)*Ar*(inv(MATRIX_r + (Ar')*Cwr^(-1)*Ar))*(Ar')*Cwr^(-1));
%Replace above with the one given in wikipedia
M_k = inv(Ar)' * MATRIX_r * inv(Ar);
C_k = M_k/(M_k + Cwr^(-1));
L_k = eye(size(Ar,2)) - C_k;
MATRIX_r = (L_k * M_k *(L_k')) + C_k * Cwr^(-1)* (C_k');
end