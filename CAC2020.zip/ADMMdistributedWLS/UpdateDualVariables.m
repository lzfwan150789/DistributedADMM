function Dual = UpdateDualVariables(Dual,Phi1,Phi2,rho)
               
    Dual = Dual + rho/2*(Phi1-Phi2);    

                
end