Notice：CAC2020 folder includes four sub-folders, namely, ADMMdistributedMAD (Ref.[8]), ADMMdistributedWLS (proposed), Centralized (cetralized form), and results (tracking results used in the main .tex file).

In the original work Ref.[8], the authors set the penalty para. to be 3. However, in our tracking scenario, the setting does not work. Due to the fact, I set the the penalty para. to be 100. Certainly, you can continue tune the para. to output another result. 

In fact, our manuscript proposes a estimator from WLS perpestive. A main merit is that it only need first and second moments. In theory, we need to testify that the proposed estimator is still valid under a nonGaussian scenario. I should do such a simulation. But I do not do that. On the one hand, I do not konw how to accomplish the algorithm in [8] under a nonGaussina case. Bacause its recursive structure requires a Gaussian condition. On the other hand, the page space is limited. As for the issue, You can ask Prof. Liang. 

Finally, Good Luck, Dr. Liu.